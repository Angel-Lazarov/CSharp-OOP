﻿namespace Telephony.Models.Interface
{
    public interface ICallable
    {
        string Call(string number);
    }
}
