﻿namespace Telephony.Models.Interface
{
    public interface IBrowsable
    {
        string Brows(string url);
    }
}
