﻿namespace Telephony.IO.Interfaces
{
    public interface IWriter
    {
        // Ти си нещо, което може да пише редове. Като приема съответният ред като параметър.
        public void WriteLine(string line);
    }
}
