﻿namespace Telephony.IO.Interfaces
{
    public interface IReader
    {
        //Ти си нещо, което може да чете редове. Всеки, който те имплементира, ще знае как да чете редове!
        string ReadLine();
    }
}
