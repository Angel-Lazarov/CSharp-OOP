﻿namespace ExplicitInterfaces.Models.Interfaces
{
    public interface IPerson
    {
        public string Name { get; }

        public int Age { get; }

        public string GetName();
    }
}
