﻿
namespace ExplicitInterfaces.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
